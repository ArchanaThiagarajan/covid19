package com.example.covid19;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.app.AlertDialog;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Button;
import android.widget.EditText;
public class Main17Activity extends AppCompatActivity implements android.view.View.OnClickListener{
    EditText name1,qual,field,dob,address,mobileNo,email;
    Button oins,oal;
    SQLiteDatabase db;
    /** Called when the activity is first created. */
    @SuppressLint("WrongViewCast")


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main17);
        name1=findViewById(R.id.ed37);
        qual= findViewById(R.id.ed38);
        field= findViewById(R.id.ed40);
        dob= findViewById(R.id.ed41);
        address= findViewById(R.id.ed42);
        mobileNo=findViewById(R.id.ed43);
        email= findViewById(R.id.ed44);
        oins=findViewById(R.id.button61);
        oal=findViewById(R.id.button62);
        oins.setOnClickListener(this);
        oal.setOnClickListener(this);
        // Creating database and table
        db=openOrCreateDatabase("vbDB", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS online(name1 VARCHAR,qual VARCHAR,field VARCHAR,dob VARCHAR,address VARCHAR,mobileNo VARCHAR,email VARCHAR);");

    }
    public void onClick(View view)
    {
        // Inserting a record to the Student table
        if(view==oins)
        {
            // Checking for empty fields
            if(name1.getText().toString().trim().length()==0||
                    qual.getText().toString().trim().length()==0||
                    field.getText().toString().trim().length()==0||
                    dob.getText().toString().trim().length()==0||
                    address.getText().toString().trim().length()==0||
                    mobileNo.getText().toString().trim().length()==0||
                    email.getText().toString().trim().length()==0)

            {
                showMessage("Error", "Please enter all values");
                return;
            }
            db.execSQL("INSERT INTO online VALUES('"+name1.getText()+"','"
                    +qual.getText()+"','"+field.getText()+"','"+dob.getText()+"','"+address.getText()+"','"+mobileNo.getText()+"','"+email.getText()+"');");
            showMessage("Success", "Record added");
            oins.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            Intent i = new Intent(Main17Activity.this, Main17Activity.class);
                                            Bundle b=new Bundle();
                                            i.putExtras(b);
                                            startActivity(i);


                                        }
                                    }
            );

        }
        // Display a record from the Student table

        // Displaying all the records
        if(view==oal)
        {
            Cursor c=db.rawQuery("SELECT * FROM online", null);
            if(c.getCount()==0)
            {
                showMessage("Error", "No records found");
                return;
            }
            StringBuffer buffer=new StringBuffer();
            while(c.moveToNext())
            {

                buffer.append("Applicants Name: "+c.getString(0)+"\n");
                buffer.append("Qualification: "+c.getString(1)+"\n\n");
                buffer.append("Field: "+c.getString(2)+"\n");
                buffer.append("Date of Birth: "+c.getString(3)+"\n");
                buffer.append("Address: "+c.getString(4)+"\n\n");
                buffer.append("Mobile No: "+c.getString(5)+"\n\n");
                buffer.append("Email Id: "+c.getString(6)+"\n\n");


            }
            showMessage("****Vocational Training Details****", buffer.toString());
        }
    }
    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}

