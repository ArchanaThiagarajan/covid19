package com.example.covid19;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.content.Intent;

import android.view.View;

import android.widget.Button;
import android.widget.Spinner;
import android.app.AlertDialog;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.EditText;
public class Main32Activity extends AppCompatActivity implements android.view.View.OnClickListener{
    Spinner sha, col;
    EditText name,ad,em,city,pn,es,ef,qty;
    Button wins,wal;
    SQLiteDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main32);
        name=(EditText)findViewById(R.id.ed137);
        ad=(EditText) findViewById(R.id.ed139);
        em=(EditText) findViewById(R.id.ed138);
        city=(EditText)findViewById(R.id.ed140);
        pn=(EditText) findViewById(R.id.ed141);
        es=(EditText) findViewById(R.id.ed142);
        ef=(EditText) findViewById(R.id.ed143);
        qty=(EditText) findViewById(R.id.ed144);
        wins=findViewById(R.id.button47);
        wal=findViewById(R.id.button75);
        wins.setOnClickListener(this);
        wal.setOnClickListener(this);
        // Creating database and table
        db=openOrCreateDatabase("rmDB", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS mater(name VARCHAR,ad VARCHAR,em VARCHAR,city VARCHAR,pn VARCHAR,es VARCHAR,ef VARCHAR,qty VARCHAR);");

    }


    public void onClick(View view)
    {
        // Inserting a record to the Student table
        if(view==wins)
        {
            // Checking for empty fields
            if(name.getText().toString().trim().length()==0||
                    ad.getText().toString().trim().length()==0||
                    em.getText().toString().trim().length()==0||
                    city.getText().toString().trim().length()==0||
                    pn.getText().toString().trim().length()==0||
                    es.getText().toString().trim().length()==0||
                    ef.getText().toString().trim().length()==0||
                    qty.getText().toString().trim().length()==0)

            {
                showMessage("Error", "Please enter all values");
                return;
            }
            db.execSQL("INSERT INTO mater VALUES('"+name.getText()+"','"+ad.getText()+
                    "','"+em.getText()+"','"+city.getText()+"','"+pn.getText()+"','"+ef.getText()+"','"+es.getText()+"','"+qty.getText()+"');");
            showMessage("Success", "Record added");
            wins.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            Intent i = new Intent(Main32Activity.this, Main32Activity.class);
                                            Bundle b=new Bundle();
                                            i.putExtras(b);
                                            startActivity(i);


                                        }
                                    }
            );

        }
        // Display a record from the Student table

        // Displaying all the records
        if(view==wal)
        {
            Cursor c=db.rawQuery("SELECT * FROM mater", null);
            if(c.getCount()==0)
            {
                showMessage("Error", "No records found");
                return;
            }
            StringBuffer buffer=new StringBuffer();
            while(c.moveToNext())
            {

                buffer.append("Name: "+c.getString(0)+"\n");
                buffer.append("Address: "+c.getString(1)+"\n");
                buffer.append("Email Id: "+c.getString(2)+"\n\n");
                buffer.append("City: "+c.getString(3)+"\n");
                buffer.append("Phone No: "+c.getString(4)+"\n");
                buffer.append("Essential Material: "+c.getString(5)+"\n");
                buffer.append("Essential Food Item: "+c.getString(6)+"\n\n");
                buffer.append("Quantity: "+c.getString(7)+"\n\n");

            }
            showMessage("****Collection of relief materials****", buffer.toString());
        }
    }
    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}

