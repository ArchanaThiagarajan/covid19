package com.example.covid19;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.content.Intent;

import android.view.View;

import android.widget.Button;
import android.widget.Spinner;
import android.app.AlertDialog;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.EditText;
public class Main33Activity extends AppCompatActivity implements android.view.View.OnClickListener{
    Spinner sha, col;
    EditText name,pn,em,ad,lm,fd,fq,pd;
    Button xins,xal;
    SQLiteDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main33);
        name=(EditText)findViewById(R.id.ed145);
        pn=(EditText) findViewById(R.id.ed146);
        em=(EditText) findViewById(R.id.ed147);
        ad=(EditText)findViewById(R.id.ed148);
        lm=(EditText) findViewById(R.id.ed149);
        fd=(EditText) findViewById(R.id.ed150);
        fq=(EditText) findViewById(R.id.ed151);
        pd=(EditText) findViewById(R.id.ed152);
        xins=findViewById(R.id.button49);
        xal=findViewById(R.id.button76);
        xins.setOnClickListener(this);
        xal.setOnClickListener(this);
        // Creating database and table
        db=openOrCreateDatabase("fsDB", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS food(name VARCHAR,pn VARCHAR,em VARCHAR,ad VARCHAR,lm VARCHAR,fd VARCHAR,fq VARCHAR,pd VARCHAR);");

    }


    public void onClick(View view)
    {
        // Inserting a record to the Student table
        if(view==xins)
        {
            // Checking for empty fields
            if(name.getText().toString().trim().length()==0||
                    pn.getText().toString().trim().length()==0||
                    em.getText().toString().trim().length()==0||
                    ad.getText().toString().trim().length()==0||
                    lm.getText().toString().trim().length()==0||
                    fd.getText().toString().trim().length()==0||
                    fq.getText().toString().trim().length()==0||
                    pd.getText().toString().trim().length()==0)

            {
                showMessage("Error", "Please enter all values");
                return;
            }
            db.execSQL("INSERT INTO food VALUES('"+name.getText()+"','"+pn.getText()+
                    "','"+em.getText()+"','"+ad.getText()+"','"+lm.getText()+"','"+fd.getText()+"','"+fq.getText()+"','"+pd.getText()+"');");
            showMessage("Success", "Record added");
            xins.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            Intent i = new Intent(Main33Activity.this, Main33Activity.class);
                                            Bundle b=new Bundle();
                                            i.putExtras(b);
                                            startActivity(i);


                                        }
                                    }
            );

        }
        // Display a record from the Student table

        // Displaying all the records
        if(view==xal)
        {
            Cursor c=db.rawQuery("SELECT * FROM food", null);
            if(c.getCount()==0)
            {
                showMessage("Error", "No records found");
                return;
            }
            StringBuffer buffer=new StringBuffer();
            while(c.moveToNext())
            {

                buffer.append("Name: "+c.getString(0)+"\n");
                buffer.append("Phone No: "+c.getString(1)+"\n");
                buffer.append("Email Id: "+c.getString(2)+"\n\n");
                buffer.append("Address: "+c.getString(3)+"\n");
                buffer.append("Land Mark: "+c.getString(4)+"\n");
                buffer.append("Food Description: "+c.getString(5)+"\n");
                buffer.append("Food Quantity: "+c.getString(6)+"\n\n");
                buffer.append("Pickup Date: "+c.getString(7)+"\n\n");

            }
            showMessage("****Collection of relief materials****", buffer.toString());
        }
    }
    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}

