package com.example.covid19;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Main5Activity extends AppCompatActivity {
    Button button8,button9,button10,button11,button13,button7,button4,button12;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);
        button8 = findViewById(R.id.button8);
        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent c = new Intent(Main5Activity.this, Main19Activity.class);
                Bundle b = new Bundle();
                c.putExtras(b);
                startActivity(c);
            }
        });
        button9 = findViewById(R.id.button9);
        button9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent c = new Intent(Main5Activity.this, Main20Activity.class);
                Bundle b = new Bundle();
                c.putExtras(b);
                startActivity(c);
            }
        });
        button10 = findViewById(R.id.button10);
        button10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent c = new Intent(Main5Activity.this, Main21Activity.class);
                Bundle b = new Bundle();
                c.putExtras(b);
                startActivity(c);
            }
        });
        button11 = findViewById(R.id.button11);
        button11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent c = new Intent(Main5Activity.this, Main22Activity.class);
                Bundle b = new Bundle();
                c.putExtras(b);
                startActivity(c);
            }
        });
        button13 = findViewById(R.id.button13);
        button13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent c = new Intent(Main5Activity.this, Main34Activity.class);
                Bundle b = new Bundle();
                c.putExtras(b);
                startActivity(c);
            }
        });
        button7 = findViewById(R.id.button7);
        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent c = new Intent(Main5Activity.this, Main38Activity.class);
                Bundle b = new Bundle();
                c.putExtras(b);
                startActivity(c);
            }
        });
        button4 = findViewById(R.id.button4);
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent c = new Intent(Main5Activity.this, Main40Activity.class);
                Bundle b = new Bundle();
                c.putExtras(b);
                startActivity(c);
            }
        });
        button12 = findViewById(R.id.button12);
        button12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent c = new Intent(Main5Activity.this, Main41Activity.class);
                Bundle b = new Bundle();
                c.putExtras(b);
                startActivity(c);
            }
        });
    }
}
