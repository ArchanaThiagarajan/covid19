package com.example.covid19;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Main9Activity extends AppCompatActivity {
    Button button16,button17,button18;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main9);
        button16 = findViewById(R.id.button16);
        button16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent c = new Intent(Main9Activity.this, Main8Activity.class);
                Bundle b = new Bundle();
                c.putExtras(b);
                startActivity(c);

            }
        });
        button17 = findViewById(R.id.button17);
        button17.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent c = new Intent(Main9Activity.this, Main10Activity.class);
                Bundle b = new Bundle();
                c.putExtras(b);
                startActivity(c);

            }
        });
        button18 = findViewById(R.id.button18);
        button18.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent c = new Intent(Main9Activity.this, Main11Activity.class);
                Bundle b = new Bundle();
                c.putExtras(b);
                startActivity(c);

            }
        });
    }
}
