package com.example.covid19;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.content.Intent;

import android.view.View;

import android.widget.Button;
import android.widget.Spinner;
import android.app.AlertDialog;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.EditText;
public class Main31Activity extends AppCompatActivity implements android.view.View.OnClickListener{
    Spinner sha, col;
    EditText name,email,pn,state,city,pin,pm;
    Button qins,qal;
    SQLiteDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main31);
        name=(EditText)findViewById(R.id.ed130);
        email=(EditText) findViewById(R.id.ed131);
        pn=(EditText) findViewById(R.id.ed132);
        state=(EditText)findViewById(R.id.ed133);
        city=(EditText) findViewById(R.id.ed134);
        pin=(EditText) findViewById(R.id.ed135);
        pm=(EditText) findViewById(R.id.ed136);
        qins=findViewById(R.id.button48);
        qal=findViewById(R.id.button74);
        qins.setOnClickListener(this);
        qal.setOnClickListener(this);
        // Creating database and table
        db=openOrCreateDatabase("cfDB", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS fund(name VARCHAR,email VARCHAR,pn VARCHAR,state VARCHAR,city VARCHAR,pin VARCHAR,pm VARCHAR);");

    }


    public void onClick(View view)
    {
        // Inserting a record to the Student table
        if(view==qins)
        {
            // Checking for empty fields
            if(name.getText().toString().trim().length()==0||
                    email.getText().toString().trim().length()==0||
                    pn.getText().toString().trim().length()==0||
                    state.getText().toString().trim().length()==0||
                    city.getText().toString().trim().length()==0||
                    pin.getText().toString().trim().length()==0||
                    pm.getText().toString().trim().length()==0)

            {
                showMessage("Error", "Please enter all values");
                return;
            }
            db.execSQL("INSERT INTO fund VALUES('"+name.getText()+"','"+email.getText()+
                    "','"+pn.getText()+"','"+state.getText()+"','"+city.getText()+"','"+pin.getText()+"','"+pm.getText()+"');");
            showMessage("Success", "Record added");
            qins.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            Intent i = new Intent(Main31Activity.this, Main31Activity.class);
                                            Bundle b=new Bundle();
                                            i.putExtras(b);
                                            startActivity(i);


                                        }
                                    }
            );

        }
        // Display a record from the Student table

        // Displaying all the records
        if(view==qal)
        {
            Cursor c=db.rawQuery("SELECT * FROM fund", null);
            if(c.getCount()==0)
            {
                showMessage("Error", "No records found");
                return;
            }
            StringBuffer buffer=new StringBuffer();
            while(c.moveToNext())
            {

                buffer.append("Name: "+c.getString(0)+"\n");
                buffer.append("Email Id: "+c.getString(1)+"\n");
                buffer.append("Phone No: "+c.getString(2)+"\n\n");
                buffer.append("State: "+c.getString(3)+"\n");
                buffer.append("City: "+c.getString(4)+"\n");
                buffer.append("Pincode: "+c.getString(5)+"\n");
                buffer.append("Payment Mode: "+c.getString(6)+"\n\n");

            }
            showMessage("****Collection of Funds****", buffer.toString());
        }
    }
    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}

