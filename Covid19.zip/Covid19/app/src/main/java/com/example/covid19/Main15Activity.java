package com.example.covid19;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.app.AlertDialog;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Button;
import android.widget.EditText;
public class Main15Activity extends AppCompatActivity implements android.view.View.OnClickListener{
    EditText name1,frm,ti,id,pan,age;
    Button gins,gal;
    SQLiteDatabase db;
    /** Called when the activity is first created. */
    @SuppressLint("WrongViewCast")


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main15);
        name1=findViewById(R.id.ed24);
        frm= findViewById(R.id.ed25);
        ti= findViewById(R.id.ed26);
        id= findViewById(R.id.ed27);
        pan= findViewById(R.id.ed28);
        age=findViewById(R.id.ed29);
        gins=findViewById(R.id.button34);
        gal=findViewById(R.id.button58);
        gins.setOnClickListener(this);
        gal.setOnClickListener(this);
        // Creating database and table
        db=openOrCreateDatabase("gaDB", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS gsb(name1 VARCHAR,frm VARCHAR,ti VARCHAR,id VARCHAR,pan VARCHAR,age VARCHAR);");

    }
    public void onClick(View view)
    {
        // Inserting a record to the Student table
        if(view==gins)
        {
            // Checking for empty fields
            if(name1.getText().toString().trim().length()==0||
                    frm.getText().toString().trim().length()==0||
                    ti.getText().toString().trim().length()==0||
                    id.getText().toString().trim().length()==0||
                    pan.getText().toString().trim().length()==0||
                    age.getText().toString().trim().length()==0)

            {
                showMessage("Error", "Please enter all values");
                return;
            }
            db.execSQL("INSERT INTO gsb VALUES('"+name1.getText()+"','"
                    +frm.getText()+"','"+ti.getText()+"','"+id.getText()+"','"+pan.getText()+"','"+age.getText()+"');");
            showMessage("Success", "Account Created");
            gins.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            Intent i = new Intent(Main15Activity.this, Main15Activity.class);
                                            Bundle b=new Bundle();
                                            i.putExtras(b);
                                            startActivity(i);


                                        }
                                    }
            );

        }
        // Display a record from the Student table

        // Displaying all the records
        if(view==gal)
        {
            Cursor c=db.rawQuery("SELECT * FROM gsb", null);
            if(c.getCount()==0)
            {
                showMessage("Error", "No records found");
                return;
            }
            StringBuffer buffer=new StringBuffer();
            while(c.moveToNext())
            {

                buffer.append("Applicants Name: "+c.getString(0)+"\n");
                buffer.append("From: "+c.getString(1)+"\n\n");
                buffer.append("To: "+c.getString(2)+"\n");
                buffer.append("Aadhaar No: "+c.getString(3)+"\n");
                buffer.append("PAN No: "+c.getString(4)+"\n\n");
                buffer.append("Age: "+c.getString(5)+"\n\n");


            }
            showMessage("****Details****", buffer.toString());
        }
    }
    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}

