package com.example.covid19;

import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.app.AlertDialog;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Button;
import android.widget.EditText;
public class Main14Activity extends AppCompatActivity implements android.view.View.OnClickListener{
    EditText name1,type,qty,frm,ti,id,mobileNo;
    Button eins,eal;
    SQLiteDatabase db;
    /** Called when the activity is first created. */
    @SuppressLint("WrongViewCast")


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main14);
        name1=findViewById(R.id.ed17);
        type= findViewById(R.id.ed18);
        qty=findViewById(R.id.ed19);
        frm= findViewById(R.id.ed20);
        ti= findViewById(R.id.ed21);
        id= findViewById(R.id.ed22);
        mobileNo= findViewById(R.id.ed23);
        eins=findViewById(R.id.button33);
        eal=findViewById(R.id.button57);
        eins.setOnClickListener(this);
        eal.setOnClickListener(this);
        // Creating database and table
        db=openOrCreateDatabase("essDB", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS edet(name1 VARCHAR,type VARCHAR,qty VARCHAR,frm VARCHAR,ti VARCHAR,id VARCHAR,mobileNo VARCHAR);");

    }
    public void onClick(View view)
    {
        // Inserting a record to the Student table
        if(view==eins)
        {
            // Checking for empty fields
            if(name1.getText().toString().trim().length()==0||
                    type.getText().toString().trim().length()==0||
                    qty.getText().toString().trim().length()==0||
                    frm.getText().toString().trim().length()==0||
                    ti.getText().toString().trim().length()==0||
                    id.getText().toString().trim().length()==0||
                    mobileNo.getText().toString().trim().length()==0)

            {
                showMessage("Error", "Please enter all values");
                return;
            }
            db.execSQL("INSERT INTO edet VALUES('"+name1.getText()+"','"
                    +type.getText()+"','"+qty.getText()+"','"+frm.getText()+"','"+ti.getText()+"','"+id.getText()+"','"+mobileNo.getText()+"');");
            showMessage("Success", "Record added");
            eins.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            Intent i = new Intent(Main14Activity.this, Main14Activity.class);
                                            Bundle b=new Bundle();
                                            i.putExtras(b);
                                            startActivity(i);


                                        }
                                    }
            );

        }
        // Display a record from the Student table

        // Displaying all the records
        if(view==eal)
        {
            Cursor c=db.rawQuery("SELECT * FROM edet", null);
            if(c.getCount()==0)
            {
                showMessage("Error", "No records found");
                return;
            }
            StringBuffer buffer=new StringBuffer();
            while(c.moveToNext())
            {

                buffer.append("Applicant's Name: "+c.getString(0)+"\n");
                buffer.append("Essential Type: "+c.getString(1)+"\n\n");
                buffer.append("Essential Quantity: "+c.getString(2)+"\n");
                buffer.append("From: "+c.getString(3)+"\n");
                buffer.append("To: "+c.getString(4)+"\n\n");
                buffer.append("Aadhaar No: "+c.getString(5)+"\n\n");
                buffer.append("Mobile No: "+c.getString(6)+"\n\n");

            }
            showMessage("Pass Details", buffer.toString());
        }
    }
    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}
