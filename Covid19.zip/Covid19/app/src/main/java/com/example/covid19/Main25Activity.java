package com.example.covid19;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.content.Intent;

import android.view.View;

import android.widget.Button;
import android.widget.Spinner;
import android.app.AlertDialog;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.EditText;
public class Main25Activity extends AppCompatActivity implements android.view.View.OnClickListener{
    Spinner sha, col;
    EditText name,gender,mobileNo,ui,td,frm,des;
    Button lins,lal;
    SQLiteDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main25);
        name=(EditText)findViewById(R.id.ed101);
        gender=(EditText) findViewById(R.id.ed102);
        mobileNo=(EditText) findViewById(R.id.ed103);
        ui=(EditText) findViewById(R.id.ed104);
        td=(EditText)findViewById(R.id.ed105);
        frm=(EditText) findViewById(R.id.ed106);
        des=(EditText) findViewById(R.id.ed107);
        lins=findViewById(R.id.button42);
        lal=findViewById(R.id.button70);
        lins.setOnClickListener(this);
        lal.setOnClickListener(this);
        // Creating database and table
        db=openOrCreateDatabase("smlDB", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS mig(name VARCHAR,gender VARCHAR,mobileNo VARCHAR,ui VARCHAR,td VARCHAR,frm VARCHAR,des VARCHAR);");

    }


    public void onClick(View view)
    {
        // Inserting a record to the Student table
        if(view==lins)
        {
            // Checking for empty fields
            if(name.getText().toString().trim().length()==0||
                    gender.getText().toString().trim().length()==0||
                    mobileNo.getText().toString().trim().length()==0||
                    ui.getText().toString().trim().length()==0||
                    td.getText().toString().trim().length()==0||
                    frm.getText().toString().trim().length()==0||
                    des.getText().toString().trim().length()==0)

            {
                showMessage("Error", "Please enter all values");
                return;
            }
            db.execSQL("INSERT INTO mig VALUES('"+name.getText()+"','"+gender.getText()+
                    "','"+mobileNo.getText()+"','"+ui.getText()+"','"+td.getText()+"','"+frm.getText()+"','"+des.getText()+"');");
            showMessage("Success", "Record added");
            lins.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            Intent i = new Intent(Main25Activity.this, Main25Activity.class);
                                            Bundle b=new Bundle();
                                            i.putExtras(b);
                                            startActivity(i);


                                        }
                                    }
            );

        }
        // Display a record from the Student table

        // Displaying all the records
        if(view==lal)
        {
            Cursor c=db.rawQuery("SELECT * FROM mig", null);
            if(c.getCount()==0)
            {
                showMessage("Error", "No records found");
                return;
            }
            StringBuffer buffer=new StringBuffer();
            while(c.moveToNext())
            {

                buffer.append("Name: "+c.getString(0)+"\n");
                buffer.append("Gender: "+c.getString(1)+"\n");
                buffer.append("Mobile No: "+c.getString(2)+"\n\n");
                buffer.append("Unique Id: "+c.getString(3)+"\n");
                buffer.append("Travel Date: "+c.getString(4)+"\n");
                buffer.append("From: "+c.getString(5)+"\n");
                buffer.append("Destination: "+c.getString(6)+"\n\n");

            }
            showMessage("****labor Details****", buffer.toString());
        }
    }
    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}

