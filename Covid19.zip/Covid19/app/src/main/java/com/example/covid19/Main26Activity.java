package com.example.covid19;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.content.Intent;

import android.view.View;

import android.widget.Button;
import android.widget.Spinner;
import android.app.AlertDialog;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.EditText;
public class Main26Activity extends AppCompatActivity implements android.view.View.OnClickListener{
    Spinner sha, col;
    EditText name,age,gender,occup,address,an,mn;
    Button uins,ual;
    SQLiteDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main26);
        name=(EditText)findViewById(R.id.ed108);
        age=(EditText) findViewById(R.id.ed110);
        gender=(EditText) findViewById(R.id.ed109);
        occup=(EditText) findViewById(R.id.ed111);
        address=(EditText)findViewById(R.id.ed112);
        an=(EditText) findViewById(R.id.ed113);
        mn=(EditText) findViewById(R.id.ed114);
        uins=findViewById(R.id.button43);
        ual=findViewById(R.id.button71);
        uins.setOnClickListener(this);
        ual.setOnClickListener(this);
        // Creating database and table
        db=openOrCreateDatabase("unlDB", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS sec(name VARCHAR,age VARCHAR,gender VARCHAR,occup VARCHAR,address VARCHAR,an VARCHAR,mn VARCHAR);");

    }


    public void onClick(View view)
    {
        // Inserting a record to the Student table
        if(view==uins)
        {
            // Checking for empty fields
            if(name.getText().toString().trim().length()==0||
                    age.getText().toString().trim().length()==0||
                    gender.getText().toString().trim().length()==0||
                    occup.getText().toString().trim().length()==0||
                    address.getText().toString().trim().length()==0||
                    an.getText().toString().trim().length()==0||
                    mn.getText().toString().trim().length()==0)

            {
                showMessage("Error", "Please enter all values");
                return;
            }
            db.execSQL("INSERT INTO sec VALUES('"+name.getText()+"','"+age.getText()+
                    "','"+gender.getText()+"','"+occup.getText()+"','"+address.getText()+"','"+an.getText()+"','"+mn.getText()+"');");
            showMessage("Success", "Record added");
            uins.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            Intent i = new Intent(Main26Activity.this, Main26Activity.class);
                                            Bundle b=new Bundle();
                                            i.putExtras(b);
                                            startActivity(i);


                                        }
                                    }
            );

        }
        // Display a record from the Student table

        // Displaying all the records
        if(view==ual)
        {
            Cursor c=db.rawQuery("SELECT * FROM sec", null);
            if(c.getCount()==0)
            {
                showMessage("Error", "No records found");
                return;
            }
            StringBuffer buffer=new StringBuffer();
            while(c.moveToNext())
            {

                buffer.append("Name: "+c.getString(0)+"\n");
                buffer.append("Age: "+c.getString(1)+"\n");
                buffer.append("Gender: "+c.getString(2)+"\n\n");
                buffer.append("Occupation: "+c.getString(3)+"\n");
                buffer.append("Address: "+c.getString(4)+"\n");
                buffer.append("Aadhaar No: "+c.getString(5)+"\n");
                buffer.append("Mobile No: "+c.getString(6)+"\n\n");

            }
            showMessage("****Sector workers Details****", buffer.toString());
        }
    }
    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}

