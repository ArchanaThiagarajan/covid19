package com.example.covid19;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.util.Random;

import android.os.Bundle;

public class Main24Activity extends AppCompatActivity {
    Button button41;
    private Object v;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main24);
        button41 = findViewById(R.id.button41);
        button41.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent c = new Intent(Main24Activity.this, Main25Activity.class);
                Bundle b = new Bundle();
                c.putExtras(b);
                startActivity(c);
            }
        });




    }

    public void perform_action(View view) {
        Random r = new Random();

        //minimum number to generate as random number
        int minNumber = 1000000;

        //maximum number to generate as random number
        int maxNumber = 100000000;

        //get the next random number within range
        // Inclusive both minimum and maximum value
        int randomNumber = r.nextInt((maxNumber - minNumber) + 1) + minNumber;

        //reference the textview widget
        TextView tv = (TextView) findViewById(R.id.text_view);

        //display the random number to textview
        tv.setText(String.valueOf(randomNumber));

    }
}