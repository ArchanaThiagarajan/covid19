package com.example.covid19;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class Main4Activity extends AppCompatActivity {
    Button b3,button5,button6,button90;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
        b3 = findViewById(R.id.b3);
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent c = new Intent(Main4Activity.this, Main5Activity.class);
                Bundle b = new Bundle();
                c.putExtras(b);
                startActivity(c);

            }
        });
        button5 = findViewById(R.id.button5);
        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent c = new Intent(Main4Activity.this, Main7Activity.class);
                Bundle b = new Bundle();
                c.putExtras(b);
                startActivity(c);

            }
        });
        button6 = findViewById(R.id.button6);
        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent c = new Intent(Main4Activity.this, Main9Activity.class);
                Bundle b = new Bundle();
                c.putExtras(b);
                startActivity(c);

            }
        });
        button90 = findViewById(R.id.button90);
        button90.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent c = new Intent(Main4Activity.this, MainActivity.class);
                Bundle b = new Bundle();
                c.putExtras(b);
                startActivity(c);

            }
        });
    }
}