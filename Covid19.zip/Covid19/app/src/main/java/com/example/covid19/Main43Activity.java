package com.example.covid19;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class Main43Activity extends AppCompatActivity {
   WebView vv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main43);
        vv=(WebView)findViewById(R.id.vv);
        Bundle b=getIntent().getExtras();
        vv.setWebViewClient(new WebViewClient());
        vv.getSettings().setJavaScriptEnabled(true);
        vv.loadUrl("https://smestreet.in/sectors/msme-ministry-issued-a-list-of-39-products-that-are-needed-to-fight-with-covid-19/");
    }
}
