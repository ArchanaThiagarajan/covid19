package com.example.covid19;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.app.AlertDialog;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Button;
import android.widget.EditText;
public class Main16Activity extends AppCompatActivity implements android.view.View.OnClickListener{
    EditText name1,gender,age,mobileNo,cat,email,ca;
    Button cins,cal;
    SQLiteDatabase db;
    /** Called when the activity is first created. */
    @SuppressLint("WrongViewCast")


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main16);
        name1=findViewById(R.id.ed30);
        gender= findViewById(R.id.ed31);
        age= findViewById(R.id.ed32);
        mobileNo= findViewById(R.id.ed33);
        cat= findViewById(R.id.ed34);
        email=findViewById(R.id.ed35);
        ca= findViewById(R.id.ed36);
        cins=findViewById(R.id.button59);
        cal=findViewById(R.id.button60);
        cins.setOnClickListener(this);
        cal.setOnClickListener(this);
        // Creating database and table
        db=openOrCreateDatabase("cbDB", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS couns(name1 VARCHAR,gender VARCHAR,age VARCHAR,mobileNo VARCHAR,cat VARCHAR,email VARCHAR,ca VARCHAR);");

    }
    public void onClick(View view)
    {
        // Inserting a record to the Student table
        if(view==cins)
        {
            // Checking for empty fields
            if(name1.getText().toString().trim().length()==0||
                    gender.getText().toString().trim().length()==0||
                    age.getText().toString().trim().length()==0||
                    mobileNo.getText().toString().trim().length()==0||
                    cat.getText().toString().trim().length()==0||
                    email.getText().toString().trim().length()==0||
                    ca.getText().toString().trim().length()==0)

            {
                showMessage("Error", "Please enter all values");
                return;
            }
            db.execSQL("INSERT INTO couns VALUES('"+name1.getText()+"','"
                    +gender.getText()+"','"+age.getText()+"','"+mobileNo.getText()+"','"+cat.getText()+"','"+email.getText()+"','"+ca.getText()+"');");
            showMessage("Success", "Record added");
            cins.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            Intent i = new Intent(Main16Activity.this, Main16Activity.class);
                                            Bundle b=new Bundle();
                                            i.putExtras(b);
                                            startActivity(i);


                                        }
                                    }
            );

        }
        // Display a record from the Student table

        // Displaying all the records
        if(view==cal)
        {
            Cursor c=db.rawQuery("SELECT * FROM couns", null);
            if(c.getCount()==0)
            {
                showMessage("Error", "No records found");
                return;
            }
            StringBuffer buffer=new StringBuffer();
            while(c.moveToNext())
            {

                buffer.append("Applicants Name: "+c.getString(0)+"\n");
                buffer.append("Gender: "+c.getString(1)+"\n\n");
                buffer.append("Age: "+c.getString(2)+"\n");
                buffer.append("Mobile No: "+c.getString(3)+"\n");
                buffer.append("Category: "+c.getString(4)+"\n\n");
                buffer.append("EmailId: "+c.getString(5)+"\n\n");
                buffer.append("No of Attenders: "+c.getString(6)+"\n\n");


            }
            showMessage("****Counselling Details****", buffer.toString());
        }
    }
    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}

