package com.example.covid19;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
public class Main18Activity extends AppCompatActivity implements AdapterView.OnItemSelectedListener, android.view.View.OnClickListener {
    Button button35;
    Spinner sha, col;
    EditText name,address,mobileno,emailid,gender,age,health,language,work,edu,skills,field;
    Button Insert,View,ViewAll;
    SQLiteDatabase db;
    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main18);
        name=(EditText)findViewById(R.id.ed48);
        address=(EditText) findViewById(R.id.ed47);
        mobileno=(EditText) findViewById(R.id.ed49);
        emailid=(EditText) findViewById(R.id.ed50);
        gender=(EditText)findViewById(R.id.ed51);
        health=(EditText) findViewById(R.id.ed52);
        language=(EditText) findViewById(R.id.ed53);
        work=(EditText) findViewById(R.id.ed54);
        edu=(EditText) findViewById(R.id.ed55);
        skills=(EditText) findViewById(R.id.ed56);
        Insert=(Button)findViewById(R.id.button55);
        ViewAll=(Button)findViewById(R.id.button54);
        Insert.setOnClickListener(this);
        ViewAll.setOnClickListener(this);
        db=openOrCreateDatabase("voDB", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS ve(name VARCHAR,address VARCHAR,mobileno VARCHAR,emailid VARCHAR,gender VARCHAR,health VARCHAR,language VARCHAR,work VARCHAR,edu VARCHAR,skills VARCHAR);");
        sha = (Spinner) findViewById(R.id.shape);

        final String shape[] = {"","Collection of relief materials food", "Food supply to isolated patients", "Teaching", "Medical and Healthcare"};
        ArrayAdapter<String> a = new ArrayAdapter<String>(Main18Activity.this, android.R.layout.simple_spinner_item, shape);
        sha.setAdapter(a);
        sha.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }



    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
    public void onClick(android.view.View view)
    {
        // Inserting a record to the Student table
        if(view==Insert)
        {
            // Checking for empty fields
            if(name.getText().toString().trim().length()==0||
                    address.getText().toString().trim().length()==0||
                    mobileno.getText().toString().trim().length()==0||
                    emailid.getText().toString().trim().length()==0||
                    gender.getText().toString().trim().length()==0||
                    health.getText().toString().trim().length()==0||
                    language.getText().toString().trim().length()==0||
                    work.getText().toString().trim().length()==0||
                    edu.getText().toString().trim().length()==0||
                    skills.getText().toString().trim().length()==0)
            {
                showMessage("Error", "Please enter all values");
                return;
            }
            db.execSQL("INSERT INTO ve VALUES('"+name.getText()+"','"+address.getText()+
                    "','"+ mobileno.getText()+"','"+emailid.getText()+"','"+gender.getText()+"','"+health.getText()+"','"+language.getText()+"','"+work.getText()+"','"+edu.getText()+"','"+skills.getText()+"');");
            showMessage("Success", "Record added");
            Insert.setOnClickListener(new View.OnClickListener() {
                                          @Override
                                          public void onClick(View v) {
                                              Intent i = new Intent(Main18Activity.this, Main18Activity.class);
                                              Bundle b=new Bundle();
                                              i.putExtras(b);
                                              startActivity(i);


                                          }
                                      }
            );
        }
        // Deleting a record from the Student table

        // Displaying all the records
        if(view==ViewAll)
        {
            Cursor c=db.rawQuery("SELECT * FROM ve", null);
            if(c.getCount()==0)
            {
                showMessage("Error", "No records found");
                return;
            }
            StringBuffer buffer=new StringBuffer();
            while(c.moveToNext())
            {
                buffer.append("name: "+c.getString(0)+"\n");
                buffer.append("address: "+c.getString(1)+"\n");
                buffer.append("Phone no: "+c.getString(2)+"\n\n");
                buffer.append("Email Id: "+c.getString(3)+"\n");
                buffer.append("Gender: "+c.getString(4)+"\n");
                buffer.append("Health Issues: "+c.getString(5)+"\n\n");
                buffer.append("Languages Known: "+c.getString(6)+"\n");
                buffer.append("Work Experience: "+c.getString(7)+"\n");
                buffer.append("Education Qualification: "+c.getString(8)+"\n\n");
                buffer.append("Skills: "+c.getString(9)+"\n");
            }
            showMessage("Volunteer details", buffer.toString());
        }
    }
    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }

}

