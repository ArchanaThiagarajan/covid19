package com.example.covid19;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Main8Activity extends AppCompatActivity {
    Button button20,button24,button21,button26,button27,button23,button22;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main8);
        button20 = findViewById(R.id.button20);
        button20.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent c = new Intent(Main8Activity.this, Main18Activity.class);
                Bundle b = new Bundle();
                c.putExtras(b);
                startActivity(c);
            }
        });
        button24 = findViewById(R.id.button24);
        button24.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent c = new Intent(Main8Activity.this, Main23Activity.class);
                Bundle b = new Bundle();
                c.putExtras(b);
                startActivity(c);
            }
        });
        button21 = findViewById(R.id.button21);
        button21.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent c = new Intent(Main8Activity.this, Main24Activity.class);
                Bundle b = new Bundle();
                c.putExtras(b);
                startActivity(c);
            }
        });
        button26 = findViewById(R.id.button26);
        button26.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent c = new Intent(Main8Activity.this, Main26Activity.class);
                Bundle b = new Bundle();
                c.putExtras(b);
                startActivity(c);
            }
        });
        button27 = findViewById(R.id.button27);
        button27.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent c = new Intent(Main8Activity.this, Main27Activity.class);
                Bundle b = new Bundle();
                c.putExtras(b);
                startActivity(c);
            }
        });
        button23 = findViewById(R.id.button23);
        button23.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent c = new Intent(Main8Activity.this, Main28Activity.class);
                Bundle b = new Bundle();
                c.putExtras(b);
                startActivity(c);
            }
        });
        button22 = findViewById(R.id.button22);
        button22.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent c = new Intent(Main8Activity.this, Main36Activity.class);
                Bundle b = new Bundle();
                c.putExtras(b);
                startActivity(c);
            }
        });
    }
}
