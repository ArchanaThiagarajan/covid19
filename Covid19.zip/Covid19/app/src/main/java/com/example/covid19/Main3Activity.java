package com.example.covid19;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;
import android.view.View;
import android.app.AlertDialog;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Button;
import android.widget.EditText;
public class Main3Activity extends AppCompatActivity implements android.view.View.OnClickListener{
    EditText name1,em,ps,cs;
    Button hins,gal,b1;
    SQLiteDatabase db;
    /** Called when the activity is first created. */
    @SuppressLint("WrongViewCast")


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        name1=findViewById(R.id.e1);
        em= findViewById(R.id.e2);
        ps= findViewById(R.id.e3);
        cs= findViewById(R.id.e4);
        hins=findViewById(R.id.b1);
        hins.setOnClickListener(this);
        // Creating database and table
        db=openOrCreateDatabase("signDB", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS page(name1 VARCHAR,em VARCHAR,ps VARCHAR,cs VARCHAR);");


    }
    public void onClick(View view)
    {
        // Inserting a record to the Student table
        if(view==hins)
        {
            // Checking for empty fields
            if(name1.getText().toString().trim().length()==0||
                    em.getText().toString().trim().length()==0||
                    ps.getText().toString().trim().length()==0||
                    cs.getText().toString().trim().length()==0)

            {
                showMessage("Error", "Please enter all values");
                return;
            }
            db.execSQL("INSERT INTO page VALUES('"+name1.getText()+"','"
                    +em.getText()+"','"+ps.getText()+"','"+cs.getText()+"');");
            showMessage("Success", "Record added");
            hins.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            Intent i = new Intent(Main3Activity.this, Main2Activity.class);
                                            Bundle b=new Bundle();
                                            i.putExtras(b);
                                            startActivity(i);


                                        }
                                    }
            );

        }
        // Display a record from the Student table

        // Displaying all the records

    }
    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}


