package com.example.covid19;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.content.Intent;

import android.view.View;

import android.widget.Button;
import android.widget.Spinner;
import android.app.AlertDialog;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.EditText;
public class Main23Activity extends AppCompatActivity implements android.view.View.OnClickListener{
    Spinner sha, col;
    EditText name,age,gender,address,mobileNo,et,we;
    Button fins,fal;
    SQLiteDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main23);
        name=(EditText)findViewById(R.id.ed94);
        age=(EditText) findViewById(R.id.ed95);
        gender=(EditText) findViewById(R.id.ed96);
        address=(EditText) findViewById(R.id.ed97);
        mobileNo=(EditText)findViewById(R.id.ed98);
        et=(EditText) findViewById(R.id.ed99);
        we=(EditText) findViewById(R.id.ed100);
        fins=findViewById(R.id.button40);
        fal=findViewById(R.id.button69);
        fins.setOnClickListener(this);
        fal.setOnClickListener(this);
        // Creating database and table
        db=openOrCreateDatabase("ewaDB", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS worker(name VARCHAR,age VARCHAR,gender VARCHAR,address VARCHAR,mobileNo VARCHAR,et VARCHAR,we VARCHAR);");

    }


    public void onClick(View view)
    {
        // Inserting a record to the Student table
        if(view==fins)
        {
            // Checking for empty fields
            if(name.getText().toString().trim().length()==0||
                    age.getText().toString().trim().length()==0||
                    gender.getText().toString().trim().length()==0||
                    address.getText().toString().trim().length()==0||
                    mobileNo.getText().toString().trim().length()==0||
                    et.getText().toString().trim().length()==0||
                    we.getText().toString().trim().length()==0)

            {
                showMessage("Error", "Please enter all values");
                return;
            }
            db.execSQL("INSERT INTO worker VALUES('"+name.getText()+"','"+age.getText()+
                    "','"+gender.getText()+"','"+address.getText()+"','"+mobileNo.getText()+"','"+et.getText()+"','"+we.getText()+"');");
            showMessage("Success", "Record added");
            fins.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            Intent i = new Intent(Main23Activity.this, Main23Activity.class);
                                            Bundle b=new Bundle();
                                            i.putExtras(b);
                                            startActivity(i);


                                        }
                                    }
            );

        }
        // Display a record from the Student table

        // Displaying all the records
        if(view==fal)
        {
            Cursor c=db.rawQuery("SELECT * FROM worker", null);
            if(c.getCount()==0)
            {
                showMessage("Error", "No records found");
                return;
            }
            StringBuffer buffer=new StringBuffer();
            while(c.moveToNext())
            {

                buffer.append("Name: "+c.getString(0)+"\n");
                buffer.append("Age: "+c.getString(1)+"\n");
                buffer.append("Gender: "+c.getString(2)+"\n\n");
                buffer.append("Address: "+c.getString(3)+"\n");
                buffer.append("Mobile No: "+c.getString(4)+"\n");
                buffer.append("Essential Type: "+c.getString(5)+"\n");
                buffer.append("Work Experience: "+c.getString(6)+"\n\n");

            }
            showMessage("****Workers Details****", buffer.toString());
        }
    }
    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}

