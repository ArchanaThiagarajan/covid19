package com.example.covid19;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.content.Intent;

import android.view.View;

import android.widget.Button;
import android.widget.Spinner;
import android.app.AlertDialog;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.EditText;
public class Main44Activity extends AppCompatActivity implements android.view.View.OnClickListener{
    Spinner sha, col;
    EditText name,gn,mn,em,rt;
    Button yins,yal;
    SQLiteDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main44);
        name=(EditText)findViewById(R.id.ed153);
        gn=(EditText) findViewById(R.id.ed154);
        mn=(EditText) findViewById(R.id.ed155);
        em=(EditText) findViewById(R.id.ed156);
        rt=(EditText)findViewById(R.id.ed157);
        yins=findViewById(R.id.button78);
        yal=findViewById(R.id.button80);
        yins.setOnClickListener(this);
        yal.setOnClickListener(this);
        // Creating database and table
        db=openOrCreateDatabase("frDB", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS res(name VARCHAR,gn VARCHAR,mn VARCHAR,em VARCHAR,rt VARCHAR);");

    }


    public void onClick(View view)
    {
        // Inserting a record to the Student table
        if(view==yins)
        {
            // Checking for empty fields
            if(name.getText().toString().trim().length()==0||
                    gn.getText().toString().trim().length()==0||
                    mn.getText().toString().trim().length()==0||
                    em.getText().toString().trim().length()==0||
                    rt.getText().toString().trim().length()==0)

            {
                showMessage("Error", "Please enter all values");
                return;
            }
            db.execSQL("INSERT INTO res VALUES('"+name.getText()+"','"+gn.getText()+
                    "','"+mn.getText()+"','"+em.getText()+"','"+rt.getText()+"');");
            showMessage("Success", "Record added");
            yins.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            Intent i = new Intent(Main44Activity.this, Main44Activity.class);
                                            Bundle b=new Bundle();
                                            i.putExtras(b);
                                            startActivity(i);


                                        }
                                    }
            );

        }
        // Display a record from the Student table

        // Displaying all the records
        if(view==yal)
        {
            Cursor c=db.rawQuery("SELECT * FROM res", null);
            if(c.getCount()==0)
            {
                showMessage("Error", "No records found");
                return;
            }
            StringBuffer buffer=new StringBuffer();
            while(c.moveToNext())
            {

                buffer.append("Name: "+c.getString(0)+"\n");
                buffer.append("Gender: "+c.getString(1)+"\n");
                buffer.append("Mobile No: "+c.getString(2)+"\n\n");
                buffer.append("Email Id: "+c.getString(3)+"\n");
                buffer.append("Responder Type: "+c.getString(4)+"\n");

            }
            showMessage("****First Responders****", buffer.toString());
        }
    }
    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}

