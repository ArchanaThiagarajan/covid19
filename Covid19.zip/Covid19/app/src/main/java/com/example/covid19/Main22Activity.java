package com.example.covid19;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.content.Intent;

import android.view.View;

import android.widget.Button;
import android.widget.Spinner;
import android.app.AlertDialog;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.EditText;
public class Main22Activity extends AppCompatActivity implements android.view.View.OnClickListener{
    Spinner sha, col;
    EditText name,age,gender,address,mobileNo,blood,hosp,dat,time;
    Button mins,mal;
    SQLiteDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main22);
        name=(EditText)findViewById(R.id.ed86);
        age=(EditText) findViewById(R.id.ed85);
        gender=(EditText) findViewById(R.id.ed87);
        address=(EditText) findViewById(R.id.ed88);
        mobileNo=(EditText)findViewById(R.id.ed89);
        blood=(EditText) findViewById(R.id.ed90);
        hosp=(EditText) findViewById(R.id.ed91);
        dat=(EditText) findViewById(R.id.ed92);
        time=(EditText) findViewById(R.id.ed93);
        mins=findViewById(R.id.button67);
        mal=findViewById(R.id.button68);
        mins.setOnClickListener(this);
        mal.setOnClickListener(this);
        // Creating database and table
        db=openOrCreateDatabase("hdDB", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS adm(name VARCHAR,age VARCHAR,gender VARCHAR,address VARCHAR,mobileNo VARCHAR,blood VARCHAR,hosp VARCHAR,dat VARCHAR,time VARCHAR);");

    }


    public void onClick(View view)
    {
        // Inserting a record to the Student table
        if(view==mins)
        {
            // Checking for empty fields
            if(name.getText().toString().trim().length()==0||
                    age.getText().toString().trim().length()==0||
                    gender.getText().toString().trim().length()==0||
                    address.getText().toString().trim().length()==0||
                    mobileNo.getText().toString().trim().length()==0||
                    blood.getText().toString().trim().length()==0||
                    hosp.getText().toString().trim().length()==0||
                    dat.getText().toString().trim().length()==0||
                    time.getText().toString().trim().length()==0)

            {
                showMessage("Error", "Please enter all values");
                return;
            }
            db.execSQL("INSERT INTO adm VALUES('"+name.getText()+"','"+age.getText()+
                    "','"+gender.getText()+"','"+address.getText()+"','"+mobileNo.getText()+"','"+blood.getText()+"','"+hosp.getText()+"','"+dat.getText()+"','"+time.getText()+"');");
            showMessage("Success", "Record added");
            mins.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            Intent i = new Intent(Main22Activity.this, Main22Activity.class);
                                            Bundle b=new Bundle();
                                            i.putExtras(b);
                                            startActivity(i);


                                        }
                                    }
            );

        }
        // Display a record from the Student table

        // Displaying all the records
        if(view==mal)
        {
            Cursor c=db.rawQuery("SELECT * FROM adm", null);
            if(c.getCount()==0)
            {
                showMessage("Error", "No records found");
                return;
            }
            StringBuffer buffer=new StringBuffer();
            while(c.moveToNext())
            {

                buffer.append("Name: "+c.getString(0)+"\n");
                buffer.append("Age: "+c.getString(1)+"\n");
                buffer.append("Gender: "+c.getString(2)+"\n\n");
                buffer.append("Address: "+c.getString(3)+"\n");
                buffer.append("Mobile No: "+c.getString(4)+"\n");
                buffer.append("Blood group: "+c.getString(5)+"\n");
                buffer.append("Hospital Name: "+c.getString(6)+"\n\n");
                buffer.append("Date: "+c.getString(7)+"\n");
                buffer.append("Time: "+c.getString(8)+"\n");

            }
            showMessage("****Admission Details****", buffer.toString());
        }
    }
    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}

