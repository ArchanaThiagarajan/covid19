package com.example.covid19;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.content.Intent;

import android.view.View;

import android.widget.Button;
import android.widget.Spinner;
import android.app.AlertDialog;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.EditText;
public class Main27Activity extends AppCompatActivity implements android.view.View.OnClickListener{
    Spinner sha, col;
    EditText name,address,email,state,city,pin,st;
    Button vins,val;
    SQLiteDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main27);
        name=(EditText)findViewById(R.id.ed115);
        address=(EditText) findViewById(R.id.ed116);
        email=(EditText) findViewById(R.id.ed117);
        state=(EditText) findViewById(R.id.ed118);
        city=(EditText)findViewById(R.id.ed119);
        pin=(EditText) findViewById(R.id.ed120);
        st=(EditText) findViewById(R.id.ed121);
        vins=findViewById(R.id.button44);
        val=findViewById(R.id.button72);
        vins.setOnClickListener(this);
        val.setOnClickListener(this);
        // Creating database and table
        db=openOrCreateDatabase("vcDB", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS vuln(name VARCHAR,address VARCHAR,email VARCHAR,state VARCHAR,city VARCHAR,pin VARCHAR,st VARCHAR);");

    }


    public void onClick(View view)
    {
        // Inserting a record to the Student table
        if(view==vins)
        {
            // Checking for empty fields
            if(name.getText().toString().trim().length()==0||
                    address.getText().toString().trim().length()==0||
                    email.getText().toString().trim().length()==0||
                    state.getText().toString().trim().length()==0||
                    city.getText().toString().trim().length()==0||
                    pin.getText().toString().trim().length()==0||
                    st.getText().toString().trim().length()==0)

            {
                showMessage("Error", "Please enter all values");
                return;
            }
            db.execSQL("INSERT INTO vuln VALUES('"+name.getText()+"','"+address.getText()+
                    "','"+email.getText()+"','"+state.getText()+"','"+city.getText()+"','"+pin.getText()+"','"+st.getText()+"');");
            showMessage("Success", "Record added");
            vins.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            Intent i = new Intent(Main27Activity.this, Main27Activity.class);
                                            Bundle b=new Bundle();
                                            i.putExtras(b);
                                            startActivity(i);


                                        }
                                    }
            );

        }
        // Display a record from the Student table

        // Displaying all the records
        if(view==val)
        {
            Cursor c=db.rawQuery("SELECT * FROM vuln", null);
            if(c.getCount()==0)
            {
                showMessage("Error", "No records found");
                return;
            }
            StringBuffer buffer=new StringBuffer();
            while(c.moveToNext())
            {

                buffer.append("Name: "+c.getString(0)+"\n");
                buffer.append("Address: "+c.getString(1)+"\n");
                buffer.append("Email Id: "+c.getString(2)+"\n\n");
                buffer.append("State: "+c.getString(3)+"\n");
                buffer.append("City: "+c.getString(4)+"\n");
                buffer.append("Pincode: "+c.getString(5)+"\n");
                buffer.append("Support Type: "+c.getString(6)+"\n\n");

            }
            showMessage("****Support to orphans****", buffer.toString());
        }
    }
    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}

