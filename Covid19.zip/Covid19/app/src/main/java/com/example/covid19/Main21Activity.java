package com.example.covid19;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.content.Intent;

import android.view.View;

import android.widget.Button;
import android.widget.Spinner;
import android.app.AlertDialog;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.EditText;
public class Main21Activity extends AppCompatActivity implements android.view.View.OnClickListener{
    Spinner sha, col;
    EditText name,age,gender,address,mobileNo,checkup,date,time;
    Button ains,aal;
    SQLiteDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main21);
        name=(EditText)findViewById(R.id.ed77);
        age=(EditText) findViewById(R.id.ed78);
        gender=(EditText) findViewById(R.id.ed79);
        address=(EditText) findViewById(R.id.ed80);
        mobileNo=(EditText)findViewById(R.id.ed81);
        checkup=(EditText) findViewById(R.id.ed82);
        date=(EditText) findViewById(R.id.ed83);
        time=(EditText) findViewById(R.id.ed84);
        ains=findViewById(R.id.button39);
        aal=findViewById(R.id.button66);
        ains.setOnClickListener(this);
        aal.setOnClickListener(this);
        // Creating database and table
        db=openOrCreateDatabase("doaDB", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS doctor(name VARCHAR,age VARCHAR,gender VARCHAR,mobileNo VARCHAR,checkup VARCHAR,date VARCHAR,time VARCHAR);");

    }


    public void onClick(View view)
    {
        // Inserting a record to the Student table
        if(view==ains)
        {
            // Checking for empty fields
            if(name.getText().toString().trim().length()==0||
                    age.getText().toString().trim().length()==0||
                    gender.getText().toString().trim().length()==0||
                    mobileNo.getText().toString().trim().length()==0||
                    checkup.getText().toString().trim().length()==0||
                    date.getText().toString().trim().length()==0||
                    time.getText().toString().trim().length()==0)

            {
                showMessage("Error", "Please enter all values");
                return;
            }
            db.execSQL("INSERT INTO doctor VALUES('"+name.getText()+"','"+age.getText()+
                    "','"+gender.getText()+"','"+mobileNo.getText()+"','"+checkup.getText()+"','"+date.getText()+"','"+time.getText()+"');");
            showMessage("Success", "Record added");
            ains.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            Intent i = new Intent(Main21Activity.this, Main21Activity.class);
                                            Bundle b=new Bundle();
                                            i.putExtras(b);
                                            startActivity(i);


                                        }
                                    }
            );

        }
        // Display a record from the Student table

        // Displaying all the records
        if(view==aal)
        {
            Cursor c=db.rawQuery("SELECT * FROM doctor", null);
            if(c.getCount()==0)
            {
                showMessage("Error", "No records found");
                return;
            }
            StringBuffer buffer=new StringBuffer();
            while(c.moveToNext())
            {

                buffer.append("Name: "+c.getString(0)+"\n");
                buffer.append("Age: "+c.getString(1)+"\n");
                buffer.append("Gender: "+c.getString(2)+"\n\n");
                buffer.append("Mobile No: "+c.getString(3)+"\n");
                buffer.append("Checkup: "+c.getString(4)+"\n");
                buffer.append("Date: "+c.getString(5)+"\n\n");
                buffer.append("Time: "+c.getString(6)+"\n");

            }
            showMessage("****Appointment Details****", buffer.toString());
        }
    }
    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}

