package com.example.covid19;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.content.Intent;

import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.app.AlertDialog;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.EditText;
public class Main20Activity extends AppCompatActivity implements android.view.View.OnClickListener{
    Spinner sha, col;
    EditText name,address,mobileno,email,gender,age,issues,symptoms,duration,weight;
    Button dins,dal;
    SQLiteDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main20);
        name=(EditText)findViewById(R.id.ed67);
        address=(EditText) findViewById(R.id.ed68);
        mobileno=(EditText) findViewById(R.id.ed69);
        email=(EditText) findViewById(R.id.ed70);
        gender=(EditText)findViewById(R.id.ed71);
        age=(EditText) findViewById(R.id.ed73);
        issues=(EditText) findViewById(R.id.ed72);
        symptoms=(EditText) findViewById(R.id.ed74);
        duration=(EditText) findViewById(R.id.ed75);
        weight=(EditText) findViewById(R.id.ed76);
        dins=findViewById(R.id.button38);
        dal=findViewById(R.id.button65);
        dins.setOnClickListener(this);
        dal.setOnClickListener(this);
        // Creating database and table
        db=openOrCreateDatabase("patDB", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS data(name VARCHAR,address VARCHAR,mobileno VARCHAR,email VARCHAR,gender VARCHAR,age VARCHAR,issues VARCHAR,symptoms VARCHAR,duration VARCHAR,weight VARCHAR);");

    }


    public void onClick(View view)
    {
        // Inserting a record to the Student table
        if(view==dins)
        {
            // Checking for empty fields
            if(name.getText().toString().trim().length()==0||
                    address.getText().toString().trim().length()==0||
                    mobileno.getText().toString().trim().length()==0||
                    email.getText().toString().trim().length()==0||
                    gender.getText().toString().trim().length()==0||
                    age.getText().toString().trim().length()==0||
                    issues.getText().toString().trim().length()==0||
                    symptoms.getText().toString().trim().length()==0||
                    duration.getText().toString().trim().length()==0||
                    weight.getText().toString().trim().length()==0)

            {
                showMessage("Error", "Please enter all values");
                return;
            }
            db.execSQL("INSERT INTO data VALUES('"+name.getText()+"','"+address.getText()+
                    "','"+ mobileno.getText()+"','"+email.getText()+"','"+gender.getText()+"','"+age.getText()+"','"+issues.getText()+"','"+symptoms.getText()+"','"+duration.getText()+"','"+weight.getText()+"');");
            showMessage("Success", "Record added");
            dins.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            Intent i = new Intent(Main20Activity.this, Main20Activity.class);
                                            Bundle b=new Bundle();
                                            i.putExtras(b);
                                            startActivity(i);


                                        }
                                    }
            );

        }
        // Display a record from the Student table

        // Displaying all the records
        if(view==dal)
        {
            Cursor c=db.rawQuery("SELECT * FROM data", null);
            if(c.getCount()==0)
            {
                showMessage("Error", "No records found");
                return;
            }
            StringBuffer buffer=new StringBuffer();
            while(c.moveToNext())
            {

                buffer.append("Name: "+c.getString(0)+"\n");
                buffer.append("Address: "+c.getString(1)+"\n");
                buffer.append("Phone no: "+c.getString(2)+"\n\n");
                buffer.append("Email Id: "+c.getString(3)+"\n");
                buffer.append("Gender: "+c.getString(4)+"\n");
                buffer.append("Age: "+c.getString(5)+"\n\n");
                buffer.append("Health Issues: "+c.getString(6)+"\n");
                buffer.append("Symptoms: "+c.getString(7)+"\n");
                buffer.append("Duration: "+c.getString(8)+"\n\n");
                buffer.append("Weight: "+c.getString(9)+"\n");

            }
            showMessage("****Patient Details****", buffer.toString());
        }
    }
    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}

