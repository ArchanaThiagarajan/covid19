package com.example.covid19;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Main11Activity extends AppCompatActivity {
    Button b13,b14,b15;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main11);
        b13 = findViewById(R.id.b33);
        b13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent c = new Intent(Main11Activity.this, Main12Activity.class);
                Bundle b = new Bundle();
                c.putExtras(b);
                startActivity(c);
            }
        });
        b14 = findViewById(R.id.b34);
        b14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent c = new Intent(Main11Activity.this, Main14Activity.class);
                Bundle b = new Bundle();
                c.putExtras(b);
                startActivity(c);
            }
        });
        b15 = findViewById(R.id.b32);
        b15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent c = new Intent(Main11Activity.this, Main15Activity.class);
                Bundle b = new Bundle();
                c.putExtras(b);
                startActivity(c);
            }
        });
    }
}
