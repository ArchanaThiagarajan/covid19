package com.example.covid19;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.app.AlertDialog;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Button;
import android.widget.EditText;
public class Main12Activity extends AppCompatActivity implements android.view.View.OnClickListener{
    EditText reason,range,dat,name,gender,age,count,id;
    Button pins,pal;
    SQLiteDatabase db;
    /** Called when the activity is first created. */
    @SuppressLint("WrongViewCast")


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main12);
        reason=findViewById(R.id.ed1);
        range= findViewById(R.id.ed2);
        dat=findViewById(R.id.ed4);
        name= findViewById(R.id.ed3);
        gender= findViewById(R.id.ed5);
        age= findViewById(R.id.ed6);
        count= findViewById(R.id.ed8);
        id= findViewById(R.id.ed7);
        pins=findViewById(R.id.button56);
        pal=findViewById(R.id.b35);
        pins.setOnClickListener(this);
        pal.setOnClickListener(this);
        // Creating database and table
        db=openOrCreateDatabase("ipbdDB", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS tr(reason VARCHAR,range VARCHAR,dat VARCHAR,name VARCHAR,gender VARCHAR,age VARCHAR,count VARCHAR,id VARCHAR);");

    }
    public void onClick(View view)
    {
        // Inserting a record to the Student table
        if(view==pins)
        {
            // Checking for empty fields
            if(reason.getText().toString().trim().length()==0||
                    range.getText().toString().trim().length()==0||
                    dat.getText().toString().trim().length()==0||
                    name.getText().toString().trim().length()==0||
                    gender.getText().toString().trim().length()==0||
                    age.getText().toString().trim().length()==0||
                    count.getText().toString().trim().length()==0||
                    id.getText().toString().trim().length()==0)
            {
                showMessage("Error", "Please enter all values");
                return;
            }
            db.execSQL("INSERT INTO tr VALUES('"+reason.getText()+"','"
                    +range.getText()+"','"+dat.getText()+"','"+name.getText()+"','"+gender.getText()+"','"+age.getText()+"','"+count.getText()+"','"+id.getText()+"');");
            showMessage("Success", "Record added");
            pins.setOnClickListener(new View.OnClickListener() {
                                          @Override
                                          public void onClick(View v) {
                                              Intent i = new Intent(Main12Activity.this, Main13Activity.class);
                                              Bundle b=new Bundle();
                                              i.putExtras(b);
                                              startActivity(i);


                                          }
                                      }
            );

        }
        // Display a record from the Student table

        // Displaying all the records
        if(view==pal)
        {
            Cursor c=db.rawQuery("SELECT * FROM tr", null);
            if(c.getCount()==0)
            {
                showMessage("Error", "No records found");
                return;
            }
            StringBuffer buffer=new StringBuffer();
            while(c.moveToNext())
            {
                buffer.append("Reason: "+c.getString(0)+"\n");
                buffer.append("Travel Range: "+c.getString(1)+"\n");
                buffer.append("Travel Date: "+c.getString(2)+"\n\n");
                buffer.append("Name: "+c.getString(3)+"\n");
                buffer.append("Gender: "+c.getString(4)+"\n");
                buffer.append("Age: "+c.getString(5)+"\n\n");
                buffer.append("No of passengers: "+c.getString(6)+"\n\n");
                buffer.append("Aadhar No: "+c.getString(7)+"\n\n");

            }
            showMessage("stock details", buffer.toString());
        }
    }
    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}

