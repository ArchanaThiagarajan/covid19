package com.example.covid19;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.content.Intent;

import android.view.View;

import android.widget.Button;
import android.widget.Spinner;
import android.app.AlertDialog;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.EditText;
public class Main30Activity extends AppCompatActivity implements android.view.View.OnClickListener{
    Spinner sha, col;
    EditText name,age,an,occup,state,city,pin,wd;
    Button jins,jal;
    SQLiteDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main30);
        name=(EditText)findViewById(R.id.ed122);
        age=(EditText) findViewById(R.id.ed123);
        an=(EditText) findViewById(R.id.ed124);
        occup=(EditText) findViewById(R.id.ed125);
        state=(EditText)findViewById(R.id.ed126);
        city=(EditText) findViewById(R.id.ed127);
        pin=(EditText) findViewById(R.id.ed128);
        wd=(EditText) findViewById(R.id.ed129);
        jins=findViewById(R.id.button46);
        jal=findViewById(R.id.button73);
        jins.setOnClickListener(this);
        jal.setOnClickListener(this);
        // Creating database and table
        db=openOrCreateDatabase("lsmDB", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS mapp(name VARCHAR,age VARCHAR,an VARCHAR,occup VARCHAR,state VARCHAR,city VARCHAR,pin VARCHAR,wd VARCHAR);");

    }


    public void onClick(View view)
    {
        // Inserting a record to the Student table
        if(view==jins)
        {
            // Checking for empty fields
            if(name.getText().toString().trim().length()==0||
                    age.getText().toString().trim().length()==0||
                    an.getText().toString().trim().length()==0||
                    occup.getText().toString().trim().length()==0||
                    state.getText().toString().trim().length()==0||
                    city.getText().toString().trim().length()==0||
                    pin.getText().toString().trim().length()==0||
                    wd.getText().toString().trim().length()==0)

            {
                showMessage("Error", "Please enter all values");
                return;
            }
            db.execSQL("INSERT INTO mapp VALUES('"+name.getText()+"','"+age.getText()+
                    "','"+an.getText()+"','"+occup.getText()+"','"+state.getText()+"','"+city.getText()+"','"+pin.getText()+"','"+wd.getText()+"');");
            showMessage("Success", "Record added");
            jins.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            Intent i = new Intent(Main30Activity.this, Main30Activity.class);
                                            Bundle b=new Bundle();
                                            i.putExtras(b);
                                            startActivity(i);


                                        }
                                    }
            );

        }
        // Display a record from the Student table

        // Displaying all the records
        if(view==jal)
        {
            Cursor c=db.rawQuery("SELECT * FROM mapp", null);
            if(c.getCount()==0)
            {
                showMessage("Error", "No records found");
                return;
            }
            StringBuffer buffer=new StringBuffer();
            while(c.moveToNext())
            {

                buffer.append("Name: "+c.getString(0)+"\n");
                buffer.append("Age: "+c.getString(1)+"\n");
                buffer.append("Aadhaar No: "+c.getString(2)+"\n\n");
                buffer.append("Occupation: "+c.getString(3)+"\n\n");
                buffer.append("State: "+c.getString(4)+"\n");
                buffer.append("City: "+c.getString(5)+"\n");
                buffer.append("Pincode: "+c.getString(6)+"\n");
                buffer.append("Work Details: "+c.getString(7)+"\n\n");

            }
            showMessage("****labor shelter mapping****", buffer.toString());
        }
    }
    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}

